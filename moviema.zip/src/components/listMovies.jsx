import React from "react";
import Movie from "./movie";
import { useState, useEffect } from "react";

export default function ListMovies() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const options = {
    method: "GET",
    headers: {
      "X-RapidAPI-Key": "31d22a1a74mshced98b321ccbfb9p170badjsnf821ac5cc879",
      "X-RapidAPI-Host": "online-movie-database.p.rapidapi.com",
    },
  };

  useEffect(() => {
    fetch(
      "https://online-movie-database.p.rapidapi.com/auto-complete?q=game%of%thr",
      options
    )
      .then((response) => response.json())
      .then((response) => console.log(response.d))
      .then((actualData) => {
        setData(actualData);
        setError(null);
      })
      .catch((err) => {
        setError(err.message);
        setData(null);
      })
  }, []);

  return (
    <div className="p-10 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
     <h1>API Posts</h1>
      {error && (
        <div>{`There is a problem fetching the post data - ${error}`}</div>
      )}
      <ul>
        
        {data &&
          data.map(({ id, q }) => (
            <li key={id}>
              <h3>{q}</h3>
            </li>
          ))}
      </ul>
     
      <Movie
        url="https://i.ytimg.com/vi/9KGaCGFRqnU/mqdefault.jpg"
        title="VAILLANTE"
        description="vghn ghjk ghjhhhhhhbv gbcfgthbv fgvcfg fgbvcfg fghb vfgyuikl;,nb"
      ></Movie>
      {/* <Movie
        url="https://www.leparisien.fr/resizer/v9WQ2XLZjWQ5Ri9JeQ4CvZ8Tj40=/840x525/cloudfront-eu-central-1.images.arcpublishing.com/leparisien/6YM665OEPJ3A645OQXEADU7FLY.jpg"
        title="LORAX"
        description="vghn ghjk ghjhhhhhhbv gbcfgthbv fgvcfg fgbvcfg fghb vfgyuikl;,nb"
      ></Movie>
      <Movie
        url="https://www.voo.be/fr/tv/regarder/content/voo/files/vod/images/376239.still.jpg"
        title="RAYA"
        description="vghn ghjk ghjhhhhhhbv gbcfgthbv fgvcfg fgbvcfg fghb vfgyuikl;,nb"
      ></Movie>
      <Movie
        url="https://d1fmx1rbmqrxrr.cloudfront.net/cnet/i/edit/2022/04/belle%20dormant%20dplus.jpeg"
        title="LA BELLE"
        description="vghn ghjk ghjhhhhhhbv gbcfgthbv fgvcfg fgbvcfg fghb vfgyuikl;,nb"
      ></Movie> */}
    </div>
  );
}
